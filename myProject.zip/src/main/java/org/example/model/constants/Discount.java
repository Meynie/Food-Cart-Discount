package org.example.model.constants;

public class Discount {
    public static final int GET_DISCOUNT = 60;
}
