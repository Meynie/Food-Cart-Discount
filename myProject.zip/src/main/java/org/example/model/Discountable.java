package org.example.model;

public interface Discountable {
    double getDiscount();
}
